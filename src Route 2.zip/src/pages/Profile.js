import React from 'react';
import {NavLink} from "react-router-dom";

function Profile({logout}) {
    return (
        <div>
            <NavLink to="/dashboard">Dashboard</NavLink>
            <h1>Hello User</h1>
            <button  onClick={logout}>Log Out</button>

        </div>
    );
}

export default Profile;