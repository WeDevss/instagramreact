import React from 'react';
import {useNavigate} from "react-router-dom"

function Auth({auther}) {

    const navigate=useNavigate()

    const onClick=()=>{
        auther()
        navigate("/profile")
    }

    return (
        <div>
            <h1>please register</h1>
            <button onClick={onClick}>Auth</button>
        </div>
    );
}

export default Auth;