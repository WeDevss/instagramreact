import React, {useState} from 'react';
import {Routes, Route, Navigate} from 'react-router-dom'
import Auth from "./pages/Auth";
import Profile from "./pages/Profile";
import Dashboard from "./pages/Dashboard";

function App(props) {
    const [user, setUser] = useState(null)

    return (
        <div>
            <Routes>
                {!user && (
                    <Route path="/auth" element={<Auth auther={() => setUser(true)}/>}/>
                )}
                {user && (
                    <>
                        <Route path="/profile" element={<Profile logout={() => setUser(false)}/>}/>
                        <Route path="/dashboard" element={<Dashboard/>}/>
                    </>
                )}
                <Route path="*" element={<Navigate  to={user ? "/profile" : "/auth"}/>}/>

            </Routes>

        </div>
    );
}

export default App;